#!/usr/bin/env zsh
set -euo pipefail

# ==============================================================================
# SWDA Enterprise — Online Staging Script for Air-Gapped Offline Kit
# Safety Default: Runs in --dry-run mode unless --execute is explicitly passed.
# Stages: (1) Portable CPython 3.11 (arm64), (2) Pip wheelhouse, (3) Recommended
# Qwen & Gemma GGUFs (imported from ~/.lmstudio/models or pulled via lms get).
# ==============================================================================

KIT_DIR="$(cd "$(dirname "$0")" && pwd)"
MODE="dry-run"
MODEL_PROFILE="${MODEL_PROFILE:-moe}"  # moe (qwen3.5-35b-a3b + gemma-4-26b-a4b) | dense (qwen3.8-27b + gemma-4-12b) | all

for arg in "$@"; do
  case "$arg" in
    --execute) MODE="execute" ;;
    --dry-run) MODE="dry-run" ;;
    --profile=*) MODEL_PROFILE="${arg#*=}" ;;
    *)
      echo "Usage: $0 [--dry-run | --execute] [--profile=moe|dense|all]"
      exit 1
      ;;
  esac
done

PYTHON_URL="https://github.com/astral-sh/python-build-standalone/releases/download/20250115/cpython-3.11.11+20250115-aarch64-apple-darwin-install_only.tar.gz"
PYTHON_TAR="${KIT_DIR}/python_runtime/cpython-3.11.11-macos-arm64.tar.gz"
WHEEL_DIR="${KIT_DIR}/wheels"
REQ_FILE="${KIT_DIR}/config/requirements_offline.lock.txt"
LMS_BIN="${HOME}/.lmstudio/bin/lms"
LM_MODELS_DIR="${HOME}/.lmstudio/models"

echo "================================================================================"
echo " SWDA Offline Kit Staging (${MODE} | profile=${MODEL_PROFILE})"
echo " Kit Root : ${KIT_DIR}"
echo "================================================================================"

mkdir -p "${KIT_DIR}/python_runtime" "${WHEEL_DIR}" "${KIT_DIR}/models" "${KIT_DIR}/installers"

run_cmd() {
  if [[ "${MODE}" == "dry-run" ]]; then
    echo "  [DRY-RUN] $*"
  else
    echo "  [EXECUTE] $*"
    eval "$@"
  fi
}

echo ""
echo "[1/4] Portable CPython 3.11 (Apple Silicon arm64)"
if [[ -f "${PYTHON_TAR}" ]]; then
  echo "  Already staged: ${PYTHON_TAR}"
else
  run_cmd "curl -fL -C - -o \"${PYTHON_TAR}\" \"${PYTHON_URL}\""
fi

echo ""
echo "[2/4] Offline Pip Wheelhouse (${REQ_FILE})"
if [[ "${MODE}" == "dry-run" ]]; then
  echo "  [DRY-RUN] Unpack ${PYTHON_TAR} temporarily and download cp311 macosx_arm64 wheels -> ${WHEEL_DIR}"
  echo "  [DRY-RUN] python3 -m pip download --dest \"${WHEEL_DIR}\" -r \"${REQ_FILE}\""
else
  TMP_PY="$(mktemp -d)"
  tar -xzf "${PYTHON_TAR}" -C "${TMP_PY}"
  "${TMP_PY}/python/bin/python3" -m pip download --dest "${WHEEL_DIR}" -r "${REQ_FILE}"
  rm -rf "${TMP_PY}"
fi

echo ""
echo "[3/4] Recommended Local GGUF Models -> ${KIT_DIR}/models/"
echo "  BenchLM Guidelines:"
echo "   - qwen3.5-35b-a3b  (https://benchlm.ai/models/qwen3-5-35b-a3b) : Primary High-Speed MoE Actor"
echo "   - qwen3.8-27b      (https://benchlm.ai/models/qwen3-8-27b)     : High-Precision Dense Actor & SQL"
echo "   - gemma-4-26b-a4b  (https://benchlm.ai/models/gemma-4-26b-a4b) : Primary MoE Review & Judge Model"
echo "   - gemma-4-12b      (https://benchlm.ai/models/gemma-4-12b)     : Compact Dense Review & Judge"

typeset -a TARGET_SLUGS
case "${MODEL_PROFILE}" in
  moe)   TARGET_SLUGS=("qwen3.5-35b-a3b" "gemma-4-26b-a4b") ;;
  dense) TARGET_SLUGS=("qwen3.8-27b" "gemma-4-12b") ;;
  all)   TARGET_SLUGS=("qwen3.5-35b-a3b" "qwen3.8-27b" "gemma-4-26b-a4b" "gemma-4-12b") ;;
  *)     echo "Unknown profile: ${MODEL_PROFILE}"; exit 1 ;;
esac

for slug in "${TARGET_SLUGS[@]}"; do
  existing=""
  if [[ -d "${LM_MODELS_DIR}" ]]; then
    existing="$(find "${LM_MODELS_DIR}" -iname "*${slug}*Q4*.gguf" 2>/dev/null | head -n 1 || true)"
  fi
  if [[ -n "${existing}" ]]; then
    rel_dir="$(dirname "${existing#${LM_MODELS_DIR}/}")"
    echo "  Found existing local GGUF for ${slug}: ${existing}"
    run_cmd "mkdir -p \"${KIT_DIR}/models/${rel_dir}\" && cp -n \"${existing}\" \"${KIT_DIR}/models/${rel_dir}/\""
  elif [[ -x "${LMS_BIN}" ]]; then
    echo "  No local GGUF cached yet for ${slug}; stage via LM Studio CLI (Q4_K_M recommended):"
    run_cmd "\"${LMS_BIN}\" get \"${slug}\" --yes || echo 'Select Q4_K_M in LM Studio UI for ${slug} then re-run to snapshot into offline_kit/models/'"
  else
    echo "  Install LM Studio first, pull ${slug} (Q4_K_M), then copy into ${KIT_DIR}/models/"
  fi
done

echo ""
echo "[4/4] Cryptographic Manifest (SHA256SUMS.txt)"
if [[ "${MODE}" == "dry-run" ]]; then
  echo "  [DRY-RUN] cd \"${KIT_DIR}\" && find python_runtime wheels models installers -type f ! -name '.gitkeep' | sort | xargs shasum -a 256 > SHA256SUMS.txt"
else
  (
    cd "${KIT_DIR}"
    STAGE_FILES="$(find python_runtime wheels models installers -type f ! -name '.gitkeep' 2>/dev/null | sort || true)"
    if [[ -n "${STAGE_FILES}" ]]; then
      echo "${STAGE_FILES}" | xargs shasum -a 256 > SHA256SUMS.txt
    else
      : > SHA256SUMS.txt
    fi
  )
  echo "  Updated ${KIT_DIR}/SHA256SUMS.txt"
fi

echo ""
if [[ "${MODE}" == "dry-run" ]]; then
  echo "Dry-run complete: zero downloads executed. Re-run with '--execute' when ready to stage files."
else
  echo "Staging complete. You may now disconnect the internet and run ./02_install_offline_airgapped.sh"
fi
