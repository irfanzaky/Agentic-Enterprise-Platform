#!/usr/bin/env zsh
set -euo pipefail

# ==============================================================================
# SWDA Enterprise — Full Air-Gapped Stack Runner (Zero Internet Access Required)
# Starts local LM Studio (:1234), offline MLflow (:5050), and offline LiteLLM
# Proxy (:4000), executes swda_enterprise.src.run_swda, and verifies all tests.
# ==============================================================================

KIT_DIR="$(cd "$(dirname "$0")" && pwd)"
SWDA_ROOT="$(cd "${KIT_DIR}/.." && pwd)"
REPO_ROOT="$(cd "${SWDA_ROOT}/.." && pwd)"
VENV_DIR="${KIT_DIR}/.venv"
LMS_BIN="${HOME}/.lmstudio/bin/lms"

# Strictly disable external HTTP/telemetry/model-hub lookups
export LITELLM_LOCAL_MODEL_COST_MAP=True
export DO_NOT_TRACK=1
export SCARF_NO_ANALYTICS=true
export ANONYMIZED_TELEMETRY=false
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export MLFLOW_ENABLE_SYSTEM_METRICS_LOGGING=false
export NO_PROXY="127.0.0.1,localhost"

if [[ -x "${VENV_DIR}/bin/python3" ]]; then
  PY_BIN="${VENV_DIR}/bin/python3"
else
  PY_BIN="$(command -v python3)"
fi

cd "${REPO_ROOT}"

PROVIDER="${LLM_PROVIDER:-local}"
MLFLOW_ARG=""

echo "================================================================================"
echo " SWDA Enterprise — Air-Gapped Runtime Bootstrap (NO_PROXY=${NO_PROXY})"
echo " Python : ${PY_BIN}"
echo "================================================================================"

# 1. Start LM Studio Server (:1234) if GGUF models exist locally
if [[ -x "${LMS_BIN}" ]]; then
  if curl -sSf http://127.0.0.1:1234/v1/models >/dev/null 2>&1; then
    echo " [LM Studio] Local server already listening on http://127.0.0.1:1234/v1"
    PROVIDER="${LLM_PROVIDER:-lmstudio}"
  else
    GGUF_AVAIL=$(find "${KIT_DIR}/models" "${HOME}/.lmstudio/models" -name "*.gguf" 2>/dev/null | head -n 1 || true)
    if [[ -n "${GGUF_AVAIL}" ]]; then
      echo " [LM Studio] Starting headless Metal server on :1234..."
      "${LMS_BIN}" server start --port 1234 || true
      PROVIDER="${LLM_PROVIDER:-lmstudio}"
    else
      echo " [LM Studio] No GGUF weights staged yet; running verified --provider local baseline."
    fi
  fi
fi

# 2. Start Offline MLflow Tracking Server (:5050) if mlflow is installed in offline .venv
if [[ -x "${VENV_DIR}/bin/mlflow" ]]; then
  if ! curl -sSf http://127.0.0.1:5050/ >/dev/null 2>&1; then
    echo " [MLflow] Starting air-gapped MLflow server at http://127.0.0.1:5050..."
    nohup "${VENV_DIR}/bin/mlflow" server \
      --backend-store-uri "sqlite:///${SWDA_ROOT}/artifacts/mlflow_tracking.db" \
      --default-artifact-root "${SWDA_ROOT}/artifacts/mlflow_artifacts" \
      --host 127.0.0.1 \
      --port 5050 >/tmp/swda_offline_mlflow.log 2>&1 &
    sleep 2
  fi
  MLFLOW_ARG="--mlflow-url http://127.0.0.1:5050"
fi

# 3. Start Offline LiteLLM Proxy (:4000) if litellm is installed & LM Studio is up
if [[ "${PROVIDER}" == "lmstudio" ]] && [[ -x "${VENV_DIR}/bin/litellm" ]]; then
  if ! curl -sSf http://127.0.0.1:4000/health/liveliness >/dev/null 2>&1; then
    echo " [LiteLLM] Starting air-gapped LiteLLM proxy at http://127.0.0.1:4000..."
    nohup "${VENV_DIR}/bin/litellm" \
      --config "${KIT_DIR}/config/litellm_offline_config.yaml" \
      --host 127.0.0.1 \
      --port 4000 >/tmp/swda_offline_litellm.log 2>&1 &
    sleep 2
  fi
fi

echo ""
echo " [SWDA] Executing run_swda --provider ${PROVIDER} ${MLFLOW_ARG} --decision APPROVE --rebuild-ui"
if [[ -n "${MLFLOW_ARG}" ]]; then
  "${PY_BIN}" -m swda_enterprise.src.run_swda --provider "${PROVIDER}" --mlflow-url http://127.0.0.1:5050 --decision APPROVE --rebuild-ui
else
  "${PY_BIN}" -m swda_enterprise.src.run_swda --provider "${PROVIDER}" --decision APPROVE --rebuild-ui
fi

echo ""
echo " [Tests] Running full SWDA security, ACL, SQL AST & UI regression suite..."
"${PY_BIN}" -m unittest discover -s swda_enterprise/tests -p "test_*.py" -v

echo ""
echo "Offline run verified. Open zero-CDN UI in browser:"
echo "  open ${SWDA_ROOT}/ui/dist/index.html"
