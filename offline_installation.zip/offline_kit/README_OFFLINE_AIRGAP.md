# SWDA Enterprise — Air-Gapped Offline Kit (`swda_enterprise/offline_kit/`)

This folder holds all installers, standalone Python runtime tarballs, pip `.whl` archives, recommended **Qwen & Gemma GGUF** local LLM weights, offline LiteLLM/MLflow configs, and verification scripts needed to operate the **SWDA Enterprise 4-Layer Platform** completely **without an internet connection**.

---

## 1. Recommended Local LLM Guidelines (Apple Silicon Metal / LM Studio `:1234`)

Per SWDA **Pillar 2** (*independent LLM-as-judge must use a distinct model family from actor agents*) and **Layer IV** local inference latency benchmarks:

| Model Role in SWDA | Recommended Model | BenchLM Reference | Architecture & Quantization Target | Apple Silicon Memory Budget |
| --- | --- | --- | --- | --- |
| **Primary Actor Model (Fast MoE)** | **`Qwen3.5-35B-A3B`** (`qwen3.5-35b-a3b`) | [benchlm.ai/models/qwen3-5-35b-a3b](https://benchlm.ai/models/qwen3-5-35b-a3b) | MoE `35B` total / `3B` active (`Q4_K_M`, ~`20–22 GB`) | `32 GB+` Unified RAM (M1/M2/M3 Max) — fast high-throughput `Trainee` / `Provider` / `Employer` rounds |
| **Primary Actor / SQL Rule Model (Dense)** | **`Qwen3.8-27B`** (`qwen3.8-27b`) | [benchlm.ai/models/qwen3-8-27b](https://benchlm.ai/models/qwen3-8-27b) | Dense `27B` (`Q4_K_M`, ~`16–18 GB`) | `32 GB+` Unified RAM — structured JSON, multi-round synthesis & `SWDA-SQL-01..06` verification |
| **Independent Critic & Judge Model (MoE)** | **`Gemma 4 26B A4B`** (`gemma-4-26b-a4b`) | [benchlm.ai/models/gemma-4-26b-a4b](https://benchlm.ai/models/gemma-4-26b-a4b) | MoE `26B` total / `4B` active (`Q4_K_M`, ~`16 GB`) | `24–32 GB+` Unified RAM — independent `Review Agent` & Pillar 2 LLM-as-judge cross-check |
| **Compact Critic & Judge Model (Dense)** | **`Gemma 4 12B`** (`gemma-4-12b`) | [benchlm.ai/models/gemma-4-12b](https://benchlm.ai/models/gemma-4-12b) | Dense `12B` (`Q4_K_M`, ~`7.5 GB`) | `16–24 GB` Unified RAM — lightweight `Review Agent` / judge for tighter memory budgets |

> **Staging Note:** No weights are pre-downloaded inside Git. Stage your chosen `Q4_K_M` `.gguf` files under `swda_enterprise/offline_kit/models/<publisher>/<model_dir>/` either via LM Studio (`~/.lmstudio/bin/lms get`) or directly on your workstation before running `02_install_offline_airgapped.sh`.

---

## 2. Offline Kit Subfolder Inventory

```text
swda_enterprise/offline_kit/
├── README_OFFLINE_AIRGAP.md
├── SHA256SUMS.txt
├── 01_download_and_stage_online.sh       # Online helper (--dry-run default; pass --execute to download)
├── 02_install_offline_airgapped.sh       # Air-gapped setup (--no-index wheels -> .venv + symlink GGUFs)
├── 03_run_full_offline_stack.sh          # Launches offline :1234 + :5050 + :4000 + SWDA + tests
├── config/
│   ├── requirements_offline.lock.txt     # Pinned wheel manifest
│   └── litellm_offline_config.yaml       # Pure-loopback routes for Qwen3.5-35B-A3B, Qwen3.8-27B, Gemma 4 26B A4B, Gemma 4 12B
├── python_runtime/                       # Portable CPython 3.11 arm64 tarball (~22 MB)
├── wheels/                               # Cached .whl packages installed via PIP_NO_INDEX=1
├── models/                               # Staged .gguf files
├── installers/                           # Optional LM-Studio-darwin-arm64.dmg copy
└── .venv/                                # Self-contained air-gapped virtual environment
```

---

## 3. Three-Step Air-Gapped Workflow

### Step A — Inspect Staging Commands (No Downloads Yet)
```zsh
chmod +x swda_enterprise/offline_kit/*.sh
./swda_enterprise/offline_kit/01_download_and_stage_online.sh --dry-run
```
When you are ready to stage Python, wheels, and models while connected to the internet:
```zsh
# Stage MoE pair (Qwen3.5-35B-A3B + Gemma 4 26B A4B), or --profile=dense, or --profile=all:
./swda_enterprise/offline_kit/01_download_and_stage_online.sh --execute --profile=moe
```

### Step B — Install Completely Offline (Wi-Fi / Ethernet Disconnected)
```zsh
./swda_enterprise/offline_kit/02_install_offline_airgapped.sh
```
This verifies `SHA256SUMS.txt`, builds `swda_enterprise/offline_kit/.venv`, installs packages strictly from `wheels/` (`PIP_NO_INDEX=1`), and symlinks `offline_kit/models/**/*.gguf` into `~/.lmstudio/models/`.

### Step C — Launch & Verify the Full Air-Gapped Stack
```zsh
./swda_enterprise/offline_kit/03_run_full_offline_stack.sh
open swda_enterprise/ui/dist/index.html
```
Exports `LITELLM_LOCAL_MODEL_COST_MAP=True`, `DO_NOT_TRACK=1`, `HF_HUB_OFFLINE=1`, and `NO_PROXY=127.0.0.1,localhost` so zero outbound DNS or HTTPS calls are made during LiteLLM (`:4000`), MLflow (`:5050`), LM Studio (`:1234`), LangGraph orchestration, or UI rendering.
