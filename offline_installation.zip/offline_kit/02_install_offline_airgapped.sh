#!/usr/bin/env zsh
set -euo pipefail

# ==============================================================================
# SWDA Enterprise — Air-Gapped Offline Installer (Run With Network Disconnected)
# Installs .venv strictly from offline_kit/wheels/ (--no-index) and links any
# GGUF weights from offline_kit/models/ into ~/.lmstudio/models/ for LM Studio.
# ==============================================================================

KIT_DIR="$(cd "$(dirname "$0")" && pwd)"
PYTHON_TAR="${KIT_DIR}/python_runtime/cpython-3.11.11-macos-arm64.tar.gz"
PY_DIR="${KIT_DIR}/.python311"
VENV_DIR="${KIT_DIR}/.venv"
WHEEL_DIR="${KIT_DIR}/wheels"
REQ_FILE="${KIT_DIR}/config/requirements_offline.lock.txt"
LM_MODELS_DIR="${HOME}/.lmstudio/models"

export PIP_NO_INDEX=1
export PIP_DISABLE_PIP_VERSION_CHECK=1
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1

echo "================================================================================"
echo " SWDA Enterprise — Air-Gapped Offline Installation"
echo "================================================================================"

if [[ -f "${KIT_DIR}/SHA256SUMS.txt" ]] && [[ -s "${KIT_DIR}/SHA256SUMS.txt" ]]; then
  echo "[1/4] Verifying SHA256SUMS.txt checksums..."
  (cd "${KIT_DIR}" && shasum -a 256 -c SHA256SUMS.txt)
else
  echo "[1/4] No SHA256SUMS.txt populated yet; skipping checksum check."
fi

echo ""
echo "[2/4] Preparing Offline Python Interpreter..."
if [[ -f "${PYTHON_TAR}" ]]; then
  rm -rf "${PY_DIR}"
  mkdir -p "${PY_DIR}"
  tar -xzf "${PYTHON_TAR}" -C "${PY_DIR}"
  BASE_PYTHON="${PY_DIR}/python/bin/python3"
  echo "  Unpacked standalone CPython: $(${BASE_PYTHON} --version)"
elif command -v /opt/homebrew/bin/python3.13 >/dev/null 2>&1; then
  BASE_PYTHON="/opt/homebrew/bin/python3.13"
  echo "  Using local Homebrew Python: $(${BASE_PYTHON} --version)"
else
  BASE_PYTHON="$(command -v python3)"
  echo "  Using system Python: $(${BASE_PYTHON} --version)"
fi

echo ""
echo "[3/4] Creating Relocatable Virtual Environment & Installing Offline Wheels..."
"${BASE_PYTHON}" -m venv --copies "${VENV_DIR}"
WHEEL_COUNT=$(find "${WHEEL_DIR}" -maxdepth 1 -name "*.whl" 2>/dev/null | wc -l | tr -d ' ')
if [[ "${WHEEL_COUNT}" -gt 0 ]]; then
  "${VENV_DIR}/bin/pip" install --no-index --find-links="${WHEEL_DIR}" -r "${REQ_FILE}"
  echo "  Installed packages strictly from ${WHEEL_COUNT} offline wheels in ${WHEEL_DIR}."
else
  echo "  WARNING: No .whl files found in ${WHEEL_DIR} yet."
  echo "  Core stdlib SWDA simulator (--provider local) and ui/dist/index.html still run cleanly;"
  echo "  run ./01_download_and_stage_online.sh --execute while online to populate wheels/."
fi

echo ""
echo "[4/4] Linking Staged GGUF Models into LM Studio (${LM_MODELS_DIR})..."
mkdir -p "${LM_MODELS_DIR}"
GGUF_COUNT=0
while IFS= read -r -d '' gguf; do
  rel="${gguf#${KIT_DIR}/models/}"
  dest_dir="${LM_MODELS_DIR}/$(dirname "${rel}")"
  mkdir -p "${dest_dir}"
  ln -sf "${gguf}" "${dest_dir}/$(basename "${gguf}")"
  echo "  Linked offline GGUF: ${rel}"
  GGUF_COUNT=$((GGUF_COUNT + 1))
done < <(find "${KIT_DIR}/models" -type f -name "*.gguf" -print0 2>/dev/null)

if [[ "${GGUF_COUNT}" -eq 0 ]]; then
  echo "  NOTE: Zero .gguf files in ${KIT_DIR}/models/ yet (stage Qwen3.5-35B-A3B / Qwen3.8-27B / Gemma 4 26B A4B / Gemma 4 12B)."
fi

echo ""
echo "Offline installation step finished cleanly. Launch with: ./swda_enterprise/offline_kit/03_run_full_offline_stack.sh"
